/*
This code defines a SettingsManager class that manages the settings of the
pharmacy management system. The SettingsManager class has properties for the
database URL, database username, database password, and sales tax percentage.
The class has getter and setter methods for each property.

The example usage of the SettingsManager class creates a
settings manager with default values, prints the settings properties, 
updates the sales tax percentage, and prints the updated sales tax percentage.
 */
package pharmacyPages;

/**
 *
 * @author DAVIS
 */

public class SettingsManager {
    
    private String cs;
    private String databaseUsername;
    private String databasePassword;
    private int salesTaxPercentage;

    public SettingsManager(String databaseUrl, String databaseUsername, String databasePassword, int salesTaxPercentage) {
        this.cs =  "jdbc:mysql://localhost:3306/pharmacy";
        this.databaseUsername = databaseUsername;
        this.databasePassword = databasePassword;
        this.salesTaxPercentage = salesTaxPercentage;
    }

    // Getter and setter methods for the settings properties
    public String getDatabaseUrl() {
        return cs;
    }

    public void setDatabaseUrl(String databaseUrl) {
        this.cs =  "jdbc:mysql://localhost:3306/pharmacy";
    }

    public String getDatabaseUsername() {
        return databaseUsername;
    }

    public void setDatabaseUsername(String databaseUsername) {
        this.databaseUsername = databaseUsername;
    }

    public String getDatabasePassword() {
        return databasePassword;
    }

    public void setDatabasePassword(String databasePassword) {
        this.databasePassword = databasePassword;
    }

    public int getSalesTaxPercentage() {
        return salesTaxPercentage;
    }

    public void setSalesTaxPercentage(int salesTaxPercentage) {
        this.salesTaxPercentage = salesTaxPercentage;
    }

    public static void main(String[] args) {
        // Example usage of the SettingsManager class
        SettingsManager settingsManager = new SettingsManager("jdbc:mysql://localhost:3306/pharmacy", "root", "password",10);

        System.out.println("Database URL: " + settingsManager.cs());
        System.out.println("Database Username: " + settingsManager.getDatabaseUsername());
        System.out.println("Database Password: " + settingsManager.getDatabasePassword());
        System.out.println("Sales Tax Percentage: " + settingsManager.getSalesTaxPercentage() + "%");

        settingsManager.setSalesTaxPercentage(12);
        System.out.println("Updated Sales Tax Percentage: " + settingsManager.getSalesTaxPercentage() + "%");
    }
}