/*
This code creates a simple login window with two fields for username and password,
and a button to submit the credentials. When the button is pressed,
the actionPerformed() method is called, and the entered username and password are retrieved.
You would need to replace the comment in the actionPerformed() method with code to check the entered credentials
against the database and show the main application window if they are valid.
 */
package pharmacyPages;

/**
 *
 * @author DAVIS
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//public class Pharmacy {
//e
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//    }
//    
//}

public class Loginaa extends JFrame implements ActionListener {

    JLabel label1, label2;
    JTextField tf1;
    JPasswordField pf;
    JButton loginButton;

    public Loginaa() {
        setTitle("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        label1 = new JLabel("Username:");
        label2 = new JLabel("Password:");
        tf1 = new JTextField(20);
        pf = new JPasswordField(20);
        loginButton = new JButton("Login");

        setLayout(new GridLayout(3, 2));
        add(label1);
        add(tf1);
        add(label2);
        add(pf);
        add(new JLabel(""));
        add(loginButton);

        loginButton.addActionListener(this);

        pack();
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String username = tf1.getText();
        String password = new String(pf.getPassword());

        // Check username and password against database here
        // If valid, close login window and show main application window
    }

    public static void main(String[] args) {
        new Loginaa();
    }
}
