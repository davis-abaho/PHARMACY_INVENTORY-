package pharmacyPages;

/*
This code creates a dashboard with three sections 
- stock levels, recent transactions, and other metrics. 
The stock and transaction data are displayed in tables with scrollable panes.
The metrics section can contain any number of visualizations, 
such as graphs or charts, depending on the specific requirements of the project. 
 */
//package pharmacy;
//
///**
// *
// * @author DAVIS
// */
//public class dashboard {
//    
//}
import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class managerialDashboard extends JFrame {

    JLabel titleLabel, stockLabel, transactionsLabel, metricsLabel;
     Connection con;
            PreparedStatement statement;
            Statement st;
            String cs;
            
            String username;
            String password;
            String Quantity; 
            
            String query;
            ResultSet rs;
            String records;
            boolean next = false;

    public managerialDashboard() {
        setTitle("SOUND-HEALTH PHARMACY");
        

        titleLabel = new JLabel("CURRENT STOCK DETAILS");//SOUND-HEALTH PHARMACY//
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        stockLabel = new JLabel("GRAPHICAL REPRESENTATION ");
        stockLabel.setFont(new Font("Arial", Font.BOLD, 16));
        stockLabel.setHorizontalAlignment(JLabel.CENTER);
       // stockLabel.setVerticalAlignment(JLabel.CENTER);

        // Sample table with stock data
        String[][] stockData = {
                {"syrup", "10", "shs.5.00"},
                {"Tablets", "20", "shs. 10.00"},
                {"drugs", "5", "shs.2.50"}
        };
        String[] stockColumns = {"Item Name", "Quantity", "Price"};

        JTable stockTable = new JTable(stockData, stockColumns);
        stockTable.setPreferredScrollableViewportSize(new Dimension(300, 100));
        JScrollPane stockScrollPane = new JScrollPane(stockTable);

        transactionsLabel = new JLabel("RECENT TRANSACTIONS");
        transactionsLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Sample table with transaction data
        String[][] transactionData = {
                {"#001", "Evarist", "syrup", "5", "shs.25.000"},
                {"#002", "SARAH", "injections", "5", "shs.26.000"},
                {"#003", "Davis", "Tablets", "10", "shs.100.000"},
                {"#004", "Mulwadde", "drugs", "2", "shs.5.000"},
                {"#004", "BRUNO", "CAPSULES", "2", "shs.5.000"}
        };      
        String[] transactionColumns = {"Invoice No.", "Customer Name", "Item Name", "Quantity", "Total"};

        JTable transactionTable = new JTable(transactionData, transactionColumns);
        transactionTable.setPreferredScrollableViewportSize(new Dimension(900, 100));
        JScrollPane transactionScrollPane = new JScrollPane(transactionTable);

        metricsLabel = new JLabel("SUMMARY OF PURCHASES");
        metricsLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Sample graphs and charts showing sales trends and stock levels
        // You can use libraries such as JFreeChart to create these visualizations

        setLayout(new GridLayout(3, 1));
        add(titleLabel);
        add(stockLabel);;
        add(stockScrollPane);
        add(transactionsLabel);
        add(transactionScrollPane);
        add(metricsLabel);

        pack();
        
    }

    public static void   main(String[]args) {
        new managerialDashboard().setVisible(true);
    }
}