/*
This code defines a ReportGenerator class that generates reports for the pharmacy.
The ReportGenerator class takes a StockManager and SalesManager as parameters. 
The ReportGenerator class has methods to generate a report for the stock status and sales. 
The generateStockStatusReport method gets a list of all items in the stock and prints a table
of the item ID, name, quantity, and price.
The generateSalesReport method gets a list of all sales and items 
sold within a given date range, calculates the total revenue, 
and prints a table of the sale ID, date, item
 */
//
import java.util.ArrayList;
import java.util.Date;

public class ReportGenerator {
    
    private StockManager stockManager;
    private SalesManager salesManager;

    public ReportGenerator(StockManager stockManager, SalesManager salesManager) {
        this.stockManager = stockManager;
        this.salesManager = salesManager;
    }

    // Method to generate a report for the stock status
    public void generateStockStatusReport() {
        ArrayList<StockManager.Item> itemList = stockManager.getAllItems();
        System.out.println("Stock Status Report");
        System.out.println("-------------------");
        System.out.println("Item ID\tItem Name\tQuantity\tPrice");
        for (StockManager.Item item : itemList) {
            System.out.println(item.getID() + "\t" + item.getName() + "\t" + item.getQuantity() + "\t\t" + item.getPrice());
        }
    }

    // Method to generate a report for the sales
    public void generateSalesReport(Date startDate, Date endDate) {
        ArrayList<SalesManager.Sale> saleList = salesManager.getAllSales();
        double totalRevenue = 0.0;
        System.out.println("Sales Report");
        System.out.println("-----------");
        System.out.println("Sale ID\tDate\t\tItem ID\tItem Name\tQuantity\tPrice");
        for (SalesManager.Sale sale : saleList) {
            Date saleDate = sale.getDate();
            if (saleDate.compareTo(startDate) >= 0 && saleDate.compareTo(endDate) <= 0) {
                ArrayList<SalesManager.Sale.Item> itemList = sale.getAllItems();
                for (SalesManager.Sale.Item item : itemList) {
                    StockManager.Item stockItem = item.getItem();
                    int quantity = item.getQuantity();
                    double price = stockItem.getPrice() * quantity;
                    totalRevenue += price;
                    System.out.println(sale.getID() + "\t" + sale.getDate() + "\t" + stockItem.getID() + "\t" + stockItem.getName() + "\t" + quantity + "\t\t" + price);
                }
            }
        }
        System.out.println("Total Revenue: " + totalRevenue);
    }

    public static void main(String[] args) {
        // Example usage of the ReportGenerator class
        StockManager stockManager = new StockManager();
        stockManager.addItem(new StockManager.Item("001", "Item A", 10, 5.00));
        stockManager.addItem(new StockManager.Item("002", "Item B", 20, 10.00));

        SalesManager salesManager = new SalesManager();
        SalesManager.Sale sale = salesManager.new Sale("001", new Date());
        sale.addItem(stockManager.searchItemByID("001"), 2);
        sale.addItem(stockManager.searchItemByID("002"), 3);
        salesManager.addSale(sale);

        ReportGenerator reportGenerator = new ReportGenerator(stockManager, salesManager);
        reportGenerator.generateStockStatusReport();
        reportGenerator.generateSalesReport(new Date(2022, 1, 1), new Date(2022, 12, 31));
    }
}
