/*
This code defines a UserManager class that manages the users
of the pharmacy management system. The UserManager class has methods
to add and remove users, search for a user by username, check if a user exists,
and authenticate a user by checking if the username and password match.
The UserManager class uses a User class to represent each user,
which has fields for the username and password.
The example usage of the UserManager class creates two users 
and adds them to the user list, then prints the user list and 
authenticates a user by checking if the username and password match.
 */
//package pharmacy;
//
///**
// *
// * @author DAVIS
// */
//public class usermanagement {
//    
//}
import java.util.ArrayList;

public class UserManager {
    
    private ArrayList<User> userList;

    public UserManager() {
        userList = new ArrayList<>();
    }

    // Method to add a new user
    public void addUser(User user) {
        userList.add(user);
    }

    // Method to remove a user
    public void removeUser(User user) {
        userList.remove(user);
    }

    // Method to search a user by username
    public User searchUserByUsername(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    // Method to check if a user exists
    public boolean userExists(String username) {
        for (User user : userList) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    // Method to authenticate a user
    public boolean authenticateUser(String username, String password) {
        User user = searchUserByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return true;
        }
        return false;
    }

    // Getter for the user list
    public ArrayList<User> getUserList() {
        return userList;
    }

    public static void main(String[] args) {
        // Example usage of the UserManager class
        UserManager userManager = new UserManager();
        User user1 = new User("admin", "password");
        User user2 = new User("john", "doe");
        userManager.addUser(user1);
        userManager.addUser(user2);

        System.out.println("User List:");
        System.out.println("----------");
        for (User user : userManager.getUserList()) {
            System.out.println(user.getUsername());
        }

        System.out.println("Authenticate User:");
        System.out.println("------------------");
        System.out.println(userManager.authenticateUser("admin", "password"));
        System.out.println(userManager.authenticateUser("admin", "wrongpassword"));
    }
}