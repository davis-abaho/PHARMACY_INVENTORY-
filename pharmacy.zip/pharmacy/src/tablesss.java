/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author DAVIS
 * 
 int totalcost = Integer.parseInt(txtTotalcost.getText()) ;
           int payment = Integer.parseInt(txtPay.getText());
           int tot = payment - totalcost;
           
1.Customers
* int price;
        int total;
        int quantity;
        
        price = Integer.ParseInt(txtPrice.getText());
        quantity = Integer.parseInt(txtQty.getValue().toString());
        total  = price * quantity; 
        
        df.addRow(new Object[]
        {
        
       

customer_id
name
address
email
email
date_of_birth
2.Employees

employee_id
name
address
email
phone_number
date_of_birth
hire_date
job_title
salary
3.Suppliers

supplier_id
name
address
email
phone_number
contact_person
4.Products

product_id
name
description
manufacturer
category
unit_price
quantity_per_unit
5.Orders

order_id
customer_id
order_date
total_amount
payment_method
6.Order_Items

order_id
product_id
quantity
unit_price
total_price
7.Purchase_Orders

purchase_order_id
supplier_id
purchase_date
total_amount
8.Purchase_Order_Items

purchase_order_id
product_id
quantity
unit_price
total_price
9.Sales

sales_id
employee_id
customer_id
sales_date
total_amount
payment_method
10.Sales_Items

sales_id
product_id
quantity
unit_price
total_price
* 
11.Stock_Transactions
transaction_id
product_id
transaction_date
transaction_type
quantity
unit_price
12.Stock_Adjustments
adjustment_id
product_id
adjustment_date
adjustment_type
quantity
unit_price
reason
13.Stock_Levels
product_id
quantity_in_stock
minimum_stock_level
14.Payment_Methods
payment_method_id
payment_method_name
15.Tax_Rates
tax_rate_id
tax_rate_percentage
 */
public class tablesss {
    
}
