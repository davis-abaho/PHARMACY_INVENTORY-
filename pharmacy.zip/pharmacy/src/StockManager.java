/*
This code defines a StockManager class that manages the stock of the pharmacy.
The StockManager class contains an inner class called Item that represents an item in the stock.
The StockManager class has methods to add, remove, and update items in the stock,
search for items by name or ID, and get a list of all items in the stock.
The main method shows an example usage of the StockManager class by adding two
items to the stock, updating the quantity and price of one item, and printing 
the details of all items in the stock. 
 */
//package pharmacy;
//
///**
// *
// * @author DAVIS
// */
//public class StockManagement {
//    
//}
import java.util.ArrayList;

public class StockManager {
    
    private ArrayList<Item> itemList;

    public StockManager() {
        itemList = new ArrayList<Item>();
    }

    // Method to add a new item to the stock
    public void addItem(Item item) {
        itemList.add(item);
    }

    // Method to remove an item from the stock
    public void removeItem(Item item) {
        itemList.remove(item);
    }

    // Method to update the stock quantity of an item
    public void updateStockQuantity(Item item, int quantity) {
        item.setQuantity(quantity);
    }

    // Method to update the price of an item
    public void updatePrice(Item item, double price) {
        item.setPrice(price);
    }

    // Method to search for an item in the stock by name
    public Item searchItemByName(String name) {
        for (Item item : itemList) {
            if (item.getName().equals(name)) {
                return item;
            }
        }
        return null;
    }

    // Method to search for an item in the stock by ID
    public Item searchItemByID(String id) {
        for (Item item : itemList) {
            if (item.getID().equals(id)) {
                return item;
            }
        }
        return null;
    }

    // Method to get a list of all items in the stock
    public ArrayList<Item> getAllItems() {
        return itemList;
    }

    // Inner class for Item
    public class Item {
        private String id;
        private String name;
        private int quantity;
        private double price;

        public Item(String id, String name, int quantity, double price) {
            this.id = id;
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }

        public String getID() {
            return id;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getPrice() {
            return price;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public void setPrice(double price) {
            this.price = price;
        }
    }

    public static void main(String[] args) {
        // Example usage of the StockManager class
        StockManager stockManager = new StockManager();
        stockManager.addItem(stockManager.new Item("001", "Item A", 10, 5.00));
        stockManager.addItem(stockManager.new Item("002", "Item B", 20, 10.00));

        Item itemA = stockManager.searchItemByID("001");
        stockManager.updateStockQuantity(itemA, 5);
        stockManager.updatePrice(itemA, 6.00);

        ArrayList<Item> allItems = stockManager.getAllItems();
        for (Item item : allItems) {
            System.out.println(item.getID() + " - " + item.getName() + " - " + item.getQuantity() + " - " + item.getPrice());
        }
    }
}