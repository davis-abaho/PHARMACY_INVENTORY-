/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//
import java.util.ArrayList;
import java.util.Date;

public class PurchaseManager {
    
    private ArrayList<Purchase> purchaseList;

    public PurchaseManager() {
        purchaseList = new ArrayList<Purchase>();
    }

    // Method to add a new purchase to the purchase list
    public void addPurchase(Purchase purchase) {
        purchaseList.add(purchase);
    }

    // Method to remove a purchase from the purchase list
    public void removePurchase(Purchase purchase) {
        purchaseList.remove(purchase);
    }

    // Method to search for a purchase by ID
    public Purchase searchPurchaseByID(String id) {
        for (Purchase purchase : purchaseList) {
            if (purchase.getID().equals(id)) {
                return purchase;
            }
        }
        return null;
    }

    // Method to get a list of all purchases
    public ArrayList<Purchase> getAllPurchases() {
        return purchaseList;
    }

    // Inner class for Purchase
    public class Purchase {
        private String id;
        private Date date;
        private ArrayList<Item> itemList;

        public Purchase(String id, Date date) {
            this.id = id;
            this.date = date;
            itemList = new ArrayList<Item>();
        }

        public String getID() {
            return id;
        }

        public Date getDate() {
            return date;
        }

        // Method to add an item to the purchase
        public void addItem(Item item, int quantity) {
            itemList.add(new Item(item, quantity));
        }

        // Method to remove an item from the purchase
        public void removeItem(Item item) {
            itemList.remove(item);
        }

        // Method to get a list of all items in the purchase
        public ArrayList<Item> getAllItems() {
            return itemList;
        }

        // Inner class for Item
        public class Item {
            private Item item;
            private int quantity;

            public Item(Item item, int quantity) {
                this.item = item;
                this.quantity = quantity;
            }

            public Item getItem() {
                return item;
            }

            public int getQuantity() {
                return quantity;
            }
        }
    }

    public static void main(String[] args) {
        // Example usage of the PurchaseManager class
        PurchaseManager purchaseManager = new PurchaseManager();
        StockManager.Item itemA = new StockManager().new Item("001", "Item A", 10, 5.00);
        StockManager.Item itemB = new StockManager().new Item("002", "Item B", 20, 10.00);
        PurchaseManager.Purchase purchase = purchaseManager.new Purchase("001", new Date());
        purchase.addItem(itemA, 5);
        purchase.addItem(itemB, 10);
        purchaseManager.addPurchase(purchase);

        PurchaseManager.Purchase foundPurchase = purchaseManager.searchPurchaseByID("001");
        ArrayList<PurchaseManager.Purchase.Item> items = foundPurchase.getAllItems();
        for (PurchaseManager.Purchase.Item item : items) {
            System.out.println(item.getItem().getID() + " - " + item.getItem().getName() + " - " + item.getQuantity());
        }
    }
}
