/*
This code defines a SalesManager class that manages the sales of the pharmacy. 
The SalesManager class contains an inner class called Sale that represents a sale.
The Sale class contains an inner class called Item that represents an item in the sale.
The SalesManager class has methods to add, remove, and search for sales, and get a list of all sales.
The Sale class has methods to add, remove, and get a list of items in the sale.
The main method shows an example usage of the SalesManager.
 */
//
import java.util.ArrayList;
import java.util.Date;

public class SalesManager {
    
    private ArrayList<Sale> saleList;

    public SalesManager() {
        saleList = new ArrayList<Sale>();
    }

    // Method to add a new sale to the sale list
    public void addSale(Sale sale) {
        saleList.add(sale);
    }

    // Method to remove a sale from the sale list
    public void removeSale(Sale sale) {
        saleList.remove(sale);
    }

    // Method to search for a sale by ID
    public Sale searchSaleByID(String id) {
        for (Sale sale : saleList) {
            if (sale.getID().equals(id)) {
                return sale;
            }
        }
        return null;
    }

    // Method to get a list of all sales
    public ArrayList<Sale> getAllSales() {
        return saleList;
    }

    // Inner class for Sale
    public class Sale {
        private String id;
        private Date date;
        private ArrayList<Item> itemList;

        public Sale(String id, Date date) {
            this.id = id;
            this.date = date;
            itemList = new ArrayList<Item>();
        }

        public String getID() {
            return id;
        }

        public Date getDate() {
            return date;
        }

        // Method to add an item to the sale
        public void addItem(Item item, int quantity) {
            itemList.add(new Item(item, quantity));
        }

        // Method to remove an item from the sale
        public void removeItem(Item item) {
            itemList.remove(item);
        }

        // Method to get a list of all items in the sale
        public ArrayList<Item> getAllItems() {
            return itemList;
        }

        // Inner class for Item
        public class Item {
            private Item item;
            private int quantity;

            public Item(Item item, int quantity) {
                this.item = item;
                this.quantity = quantity;
            }

            public Item getItem() {
                return item;
            }

            public int getQuantity() {
                return quantity;
            }
        }
    }

    public static void main(String[] args) {
        // Example usage of the SalesManager class
        SalesManager salesManager = new SalesManager();
        StockManager.Item itemA = new StockManager().new Item("001", "Item A", 10, 5.00);
        StockManager.Item itemB = new StockManager().new Item("002", "Item B", 20, 10.00);
        SalesManager.Sale sale = salesManager.new Sale("001", new Date());
        sale.addItem(itemA, 2);
        sale.addItem(itemB, 3);
        salesManager.addSale(sale);

        SalesManager.Sale foundSale = salesManager.searchSaleByID("001");
        ArrayList<SalesManager.Sale.Item> items = foundSale.getAllItems();
        for (SalesManager.Sale.Item item : items) {
            System.out.println(item.getItem().getID() + " - " + item.getItem().getName() + " - " + item.getQuantity());
        }
    }
}
